  (fluidPage(theme = 'zoo.css',


    fluidRow(div(style="height:50px")),

     tags$img(src = "istats1.gif",
              height = "450px", width = "524px"))

    # tags$img(src = "logo_stocsy.gif",
    #          height = "200px", width = "450px"))
    )
