
 fluidPage(theme = 'zoo.css',

                  fluidRow(

                    tags$b("If you identify any problem in iSTATS or need some help, please contact us at: keng@ufg.br"
                    ),
                    br(),
                    tags$b("Or in github page"
                    ),
                    tags$a(href="https://github.com/vitor-mendes-iq/iSTATS/issues", "Click here!")


                  )
 )
